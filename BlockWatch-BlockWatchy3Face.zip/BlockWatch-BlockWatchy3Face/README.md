# BLOCKWATCH
BLOCKWATCH

Clone Square_1_27pt7b.h file into C:\Users\.....\Documents\Arduino\libraries\Adafruit_GFX_Library\Fonts

Replace existing Watchy.cpp and Watchy.h files in C:\Users\.......\Documents\Arduino\libraries\Watchy\src with this repo's Watchy.cpp and Watchy.h files.

Clone BLOCKWATCH.ino file into C:\Users\.......\Documents\Arduino.

Open Arduino IDE, File/Open, search for BLOCKWATCH.ino and open.

Upload and enjoy.
